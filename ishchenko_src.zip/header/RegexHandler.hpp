#ifndef REGEXHANDLER_HPP
#define REGEXHANDLER_HPP

#include <string>
#include <vector>
#include <regex>

class RegexHandler {

public:
    RegexHandler();

    std::vector<std::pair<std::string, std::string>> findHyperlinks(const std::string& text);
    void reformat_date(const char* date, char* new_format);
    void replace_datetime(const char *filepath);
    int find_and_convert_numbers(std::string filepath);

private:
    const std::regex hyperlinkRegex;
};

#endif // REGEXHANDLER_HPP
