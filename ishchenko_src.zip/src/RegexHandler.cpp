
#include <fstream>
#include <iomanip>
#include <chrono>

RegexHandler::RegexHandler() : hyperlinkRegex(R"((\b\w+\b)(\s+)(https?://\S+))") {}

std::vector<std::pair<std::string, std::string>> RegexHandler::findHyperlinks(const std::string& text) {
    std::vector<std::pair<std::string, std::string>> links;
    std::smatch match;
    std::string::const_iterator searchStart(text.cbegin());

    while (std::regex_search(searchStart, text.cend(), match, hyperlinkRegex)) {
        links.emplace_back(match[1], match[3]);
        searchStart = match.suffix().first;
    }

    return links;
}


const char* get_month_name(int month) {
    const char* months[] = {
            "January", "February", "March", "April",
            "May", "June", "July", "August",
            "September", "October", "November", "December"
    };
    if (month < 1 || month > 12) {
        return NULL;
    }
    return months[month - 1];
}

int is_leap_year(int year) {
    return (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
}

int get_days_in_month(int month, int year) {
    switch (month) {
        case 2: // Лютий
            return is_leap_year(year) ? 29 : 28;
        case 4: case 6: case 9: case 11: // Квітень, Червень, Вересень, Листопад
            return 30;
        default:
            return 31;
    }
}

int is_valid_date(int day, int month, int year) {
    if (month < 1 || month > 12) return 0;
    if (day < 1 || day > get_days_in_month(month, year)) return 0;
    return 1;
}

void RegexHandler::reformat_date(const char *date, char *new_format) {
    int day, month, year;
    if (sscanf(date, "%d.%d.%d", &day, &month, &year) == 3 ||
        sscanf(date, "%d/%d/%d", &day, &month, &year) == 3) {

        if (day > year) {
            int copy = day;
            day = year;
            year = copy;
        }

        if (year < 100) {
            year += (year < 50) ? 2000 : 1900;
        }

        if (!is_valid_date(day, month, year)) {
            strcpy(new_format, "invalid date");
            return;
        }

        const char* month_name = get_month_name(month);
        if (month_name) {
            sprintf(new_format, "%02d %s %02d", year, month_name, day);
            return;
        }
    }
    strcpy(new_format, "невідповідний формат дати");
}

int RegexHandler::find_and_convert_numbers(std::string filepath) {
    std::fstream numberfile(filepath);
    if (!numberfile.is_open()) {
        std::cerr << "Error opening input file" << std::endl;
        return 1;
    }

    std::regex numberRegex(R"([-+]?(\d+\.\d+|\d+|\.\d+)([eE][-+]?\d+)?)");
    std::string line;

    while (std::getline(numberfile, line)) {
        std::sregex_iterator it(line.begin(), line.end(), numberRegex);
        std::sregex_iterator end;

        while (it != end) {
            std::string numberStr = it->str();
            double number = std::stod(numberStr);

            std::ostringstream formattedNumber;
            formattedNumber << std::fixed << std::setprecision(4) << number;

            std::cout << "(" << formattedNumber.str() << ")" << std::endl;

            ++it;
        }
    }
    return 0;
}

void RegexHandler::replace_datetime(const char *filepath) {
    std::ifstream inputFile(filepath);
    if (!inputFile.is_open()) {
        std::cerr << "Error opening input file" << std::endl;
        return;
    }

    auto now = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
    std::tm* tmNow = std::localtime(&now);
    std::stringstream replacement;
    replacement << std::put_time(tmNow, "%Y-%m-%d %H:%M:%S");

    std::ofstream tempFile("temp_file.txt");
    if (!tempFile.is_open()) {
        std::cerr << "Error creating temporary file" << std::endl;
        return;
    }

    std::string line;
    std::regex dateTimeRegex(R"(\b(\d{1,2}/\d{1,2}/(?:\d{2}|\d{4})|\d{1,2}\.\d{1,2}\.\d{2,4})\b)");

    while (std::getline(inputFile, line)) {
        line = std::regex_replace(line, dateTimeRegex, replacement.str());
        tempFile << line << std::endl;
    }

    inputFile.close();
    tempFile.close();

    std::remove(filepath);
    std::rename("temp_file.txt", filepath);
}
