#include <iostream>
#include "../header/RegexHandler.hpp"
#include "../src/RegexHandler.cpp"

int main() {
    std::fstream inputFile(R"(tests\RegexHandler_test.txt)");

    if (!inputFile.is_open()) {
        std::cerr << "Error opening RegexHandler_test.txt" << std::endl;
        return 1;
    }

    std::string text;
    std::string line;

    while (std::getline(inputFile, line)) {
        text += line + "\n";
    }

    inputFile.close();

    RegexHandler handler;
    auto links = handler.findHyperlinks(text);

    for (const auto& pair : links) {
        std::cout << "Word: " << pair.first << " Link: " << pair.second << std::endl;
    }

    std::fstream dateFile(R"(tests\RegexHandler_date_test.txt)");
    if (!dateFile.is_open()) {
        std::cerr << "Error opening file" << std::endl;
        return 1;
    }

    while (std::getline(dateFile, line)) {
        char format[30];
        handler.reformat_date(line.c_str(), format);
        std::cout << "Formated: " << format << std::endl;
    }


    handler.find_and_convert_numbers(R"(RegexHandler_number_test.txt)");
    handler.replace_datetime(R"(tests\RegexHandler_datereplace_test.txt)");

    return 0;
}
